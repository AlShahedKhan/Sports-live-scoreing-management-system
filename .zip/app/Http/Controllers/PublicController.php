<?php

namespace App\Http\Controllers;

use App\Models\Matchh;
use App\Models\Score;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PublicController extends Controller
{
    public function view()
    {
        $data = Score::all();
        $match = Matchh::orderby('match_datetime', 'ASC')->where('is_game_over', 0)->get();
        $match1 = Matchh::orderby('match_datetime', 'DESC')->where('is_game_over', 1)->get();
        $match2 = Matchh::orderby('match_datetime', 'DESC')->where('is_game_over', 2)->get();
        return view('public.index', compact('data', 'match', 'match1', 'match2'));
    }

    public function getStates(Request $request)
    {
        $matchData = DB::table('scores')
        ->join('players', 'scores.player_id', '=', 'players.id')
        ->join('teams','scores.team_id','=','teams.id')
        ->join('matchhs','scores.match_id','=','matchhs.id')
        ->join('scoreupdates', function($join)
        {
            $join->on('scores.one_id', '=', 'scoreupdates.id')
            ->orOn('scores.two_id','=','scoreupdates.id')
            ->orOn('scores.three_id','=','scoreupdates.id');
        })
        ->where('scores.match_id', $request->match_id)
        ->select('scores.*', 'players.player_name','teams.team_name','matchhs.match_name','scoreupdates.one','scoreupdates.two'
        ,'scoreupdates.three')
        ->get();

      if (count($matchData) > 0) {
          return response()->json($matchData);
      }
    }
}
